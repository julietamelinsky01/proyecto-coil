#include <ctime>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
//La libreria de abajo nos sirve para poder crear los arreglos din?micos (tiene new y delete)
#include<stdlib.h>

using namespace std;

class Nodo {
private:
    string dato;
    Nodo* siguiente;

public:
    string getDato() {
        return dato;
    }

    void setDato(string d) {
        dato = d;
    }

    Nodo* getSiguiente() {
        return siguiente;
    }

    void setSiguiente(Nodo* siguiente) {
        this->siguiente = siguiente;
    }
};

class Lista {
private:
    Nodo* inicio;

public:
    Lista();

    int getTamanio();

    void insertarUltimo(string dato);

    void getDatoPorDeposito(int pos[], int, int, int);

    void getDato(int pos[], int, int, bool);

    void vaciar();

    int sumarDeposito();

    int* minimoDeposito(int, int&);
};

//Constructor
Lista::Lista() { inicio = nullptr; }

//Metodo para obtener la cantidad de nodos de la lista 
int Lista::getTamanio() {
    Nodo* aux = inicio;
    int size = 0;

    while (aux != nullptr) {
        aux = aux->getSiguiente();
        size++;
    }

    return size;
}


//Inserta un nodo con el dato en la ultima posicion
void Lista::insertarUltimo(string dato) {
    Nodo* aux = inicio, * nuevo;
    nuevo = new Nodo;
    nuevo->setDato(dato);

    if (aux == nullptr) {
        nuevo->setSiguiente(inicio);
        inicio = nuevo;
        return;
    }

    while (aux->getSiguiente() != nullptr) {
        aux = aux->getSiguiente();
    }

    nuevo->setSiguiente(aux->getSiguiente());
    aux->setSiguiente(nuevo);
}

//Obtener el dato del nodo en la posicion pos 
void Lista::getDato(int pos[], int longi, int cantidad, bool comp) {
    Nodo* aux = inicio;
    int posActual = 0;
    int i;
    if(comp)    
        cout << "Articulos con " << cantidad << " existencias o menos de stock:" << endl;
    else
        cout << "Articulos con " << cantidad << " existencias o mas de stock:" << endl;
    for (i = 0; i < longi; i++) {
        if (posActual == pos[i]) {
            cout << i + 1 << ". " << aux->getDato() << endl;
        }
        else
            i--;
        posActual++;
        aux = aux->getSiguiente();
    }
}

void Lista::getDatoPorDeposito(int pos[], int longitud, int cantidad, int dep) {
    Nodo* aux = inicio;
    int posActual = 0;
    int i;
    cout << "Art?culos con " << cantidad << " existencias o menos de stock en el deposito:" << dep << endl;
    for (i = 0; i < longitud; i++) {
        if (posActual == pos[i]) {
            cout << i + 1 << ". " << aux->getDato() << endl;
        }
        else
            i--;
        posActual++;
        aux = aux->getSiguiente();
    }
}

//Funci?n que vacia la lista enlazada 
void Lista::vaciar() {
    Nodo* aux = inicio, * aBorrar;

    while (aux != nullptr) {
        aBorrar = aux;
        aux = aux->getSiguiente();
        delete aBorrar;
    }

    inicio = nullptr;

}
int Lista::sumarDeposito() {
    Nodo* aux = inicio;
    int cont = 0, suma = 0, valor;
    while (aux != nullptr) {
        if (aux->getDato() == "" || aux->getDato() == "\"")
            aux = aux->getSiguiente();
        else {
            valor = stoi(aux->getDato());
            suma += valor;
            aux = aux->getSiguiente();
        }
        cont++;
    }
    return suma;
}
int* Lista::minimoDeposito(int min, int& longitud) {
    Nodo* aux = inicio;
    int cont = 0, i = 0;
    int* posiciones = new int[getTamanio()];
    int* posicionesFinal;

    while (cont < getTamanio()) {
        if (aux->getDato() == "")
            aux->setDato("0");
        if (stoi(aux->getDato()) <= min) {
            posiciones[i] = cont;
            i++;
            aux = aux->getSiguiente();
        }
        else
            aux = aux->getSiguiente();
        cont++;
    }
    cont = 0;
    while (posiciones[cont] >= 0) {
        longitud++;
        cont++;
    }
    posicionesFinal = new int[longitud];
    for (i = 0; i < longitud; i++)
        posicionesFinal[i] = posiciones[i];

    return posicionesFinal;
}

bool encontrarCaracter(string cadena, char caracter) {
    for (int i = 0; i < cadena.length(); i++) {
        if (cadena[i] == caracter) {
            return true;  // Devuelve la posici?n del primer car?cter encontrado
        }
    }
    return false;  // Retorna -1 si el car?cter no se encuentra en la cadena
}

int main(int argc, char **argv) { // ingresar argumentos

    cout<<"cantidad de argumentos: "<<argc<<endl;
    for (int i = 0; i < argc; ++i) {
        cout<< "argumento "<< i <<": "<<argv[i]<<endl;


        if (::strcmp(argv[i], "Inventario Fisico")==0){
            cout<<"nombre del archivo: "<<argv[i+1]<<endl;
            break;
        }
    }
    clock_t begin;


    ifstream archivo;
    int cantArticulos, sumaProductos = 0, min, longitud = 0, i = 0, eleccionDeposito, cont = 0, contador = 0, cantidadObjetos = 0, contadorAncho = 0, iteraciones = 0;
    int* arregloPosiciones;
    int* posicion;
    string artic;
    string opciones;
    Lista articulo;
    Lista Depositos;



    cout << "Lista de comandos : \n";
    cout << "total_art_dif                        Cantidad total de articulos diferentes.\n";
    cout << "total_art                            Cantidad total de articulos.\n";
    cout << "min_stock [n]                        Listado de articulos con cantidad n o menos de stock.\n";
    cout << "min_stock [n],[deposito]             Listado de articulos con cantidad n o menos de stock segun un deposito.\n";
    cout << "stock [nombre_articulo]              El stock total del articulo ingresado como argumento.\n";
    cout << "stock [nombre_articulo],[deposito]   El stock del articulo en un deposito.\n";
    cout << "max_Stock [n]                        Listado de aquellos articulos cuyo stock es igual o supera el numero n.\n";
    cout << "n = numero de articulos\n\n";

    cout << "Ingrese su comando: ";
    getline(cin, opciones);

    std::istringstream ss(opciones);
    std::vector<std::string> comandos;
    std::string comando;



    if (encontrarCaracter(opciones, ' ')) {
        std::getline(ss, comando, ' ');
        comandos.push_back(comando);
    }


    if (encontrarCaracter(opciones, ',')) {
        std::getline(ss, comando, ',');
        comandos.push_back(comando);
    }

    std::getline(ss, comando);
    comandos.push_back(comando);

    archivo.open("Inventariado Fisico.csv", ios::in);       //Abrimos el archivo en modo lectura
    if (archivo.fail())         //Notificamos en caso de error
        cout << "Error";
    string linea;
    char delimitador = ',';     //Va a ser el separador de los diferentes datos
    getline(archivo, linea);    //Nos saltamos la primera fila que son solo los nombres de la tabla
    while (getline(archivo, linea)) {
        stringstream stream(linea);
        string ancho;
        while (getline(stream, ancho, delimitador) && cont == 0)
            contadorAncho++;
        cont++;
        cantidadObjetos++;
        iteraciones++;
    }
    cont = 0;

    archivo.close();

    archivo.open("Inventariado Fisico.csv", ios::in);       //Abrimos el archivo en modo lectura
    getline(archivo, linea);    //Nos saltamos la primera fila que son solo los nombres de la tabla

    cout << "Comenzando a medir Tiempo\n" << endl;
    begin = clock();

    if (comandos[0] == "total_art_dif") {
        //Cantidad total de art?culos diferentes
        while (getline(archivo, linea)) {
            stringstream stream(linea);
            string Articulo;
            cont = 0;
            while (cont < 3) {
                getline(stream, Articulo, delimitador);
                cont++;
                iteraciones++;
            }
            articulo.insertarUltimo(Articulo);
            iteraciones++;
        }
        cantArticulos = articulo.getTamanio();
        cout << "Hay " << cantArticulos << " articulos diferentes." << endl;
        cout << "Iteraciones: " << iteraciones << endl;

    }
    if (comandos[0] == "total_art") {
        //Cantidad total de art?culos
        while (getline(archivo, linea)) {
            stringstream stream(linea);
            string depositos;
            cont = 0;
            while (getline(stream, depositos, delimitador)) {
                if (cont >= 3)
                    Depositos.insertarUltimo(depositos);
                cont++;
                iteraciones++;
            }
            sumaProductos += Depositos.sumarDeposito();
            Depositos.vaciar();
            iteraciones++;
        }
        cout << "Hay " << sumaProductos << " articulos en total." << endl;
        cout << "Iteraciones: " << iteraciones << endl;

    }
    if (comandos[0] == "min_stock" && comandos.size() == 2) {
        //Listado de art?culos con cantidad n o menos de stock.
        min = stoi(comandos[1]);
        arregloPosiciones = new int[cantidadObjetos];
        if (min < 0) {
            cout << "El stock no puede ser menor a 0" << endl;
            iteraciones++;
            cout << "Iteraciones: " << iteraciones << endl;
        }
        else {
            while (getline(archivo, linea)) {
                stringstream stream(linea);
                string Articulo, depositos;
                cont = 0;
                while (getline(stream, depositos, delimitador)) {
                    if (cont == 2)
                        articulo.insertarUltimo(depositos);
                    if (cont >= 3)
                        Depositos.insertarUltimo(depositos);
                    cont++;
                    iteraciones++;
                }
                sumaProductos = Depositos.sumarDeposito();
                if (sumaProductos <= min) {
                    arregloPosiciones[i] = contador;
                    i++;
                }
                contador++;
                Depositos.vaciar();
                iteraciones++;
            }
            i = 0;
            while (arregloPosiciones[i] >= 0) {
                longitud++;
                i++;
            }
            posicion = new int[longitud];
            for (i = 0; i < longitud; i++)
                posicion[i] = arregloPosiciones[i];

            articulo.getDato(posicion, longitud, min, true);
            cout << "Iteraciones: " << iteraciones << endl;
        }
    }
    if (comandos[0] == "min_stock" && comandos.size() == 3) {
        //Listado de art?culos con cantidad n o menos de stock seg?n un dep?sito
        min = std::stoi(comandos[1]);
        eleccionDeposito = std::stoi(comandos[2]);

        if (min < 0) {
            cout << "El stock no puede ser menor a 0" << endl;
            iteraciones++;
            cout << "Iteraciones: " << iteraciones << endl;
        }
        else if (eleccionDeposito < 0 || eleccionDeposito >= contadorAncho - 2) {
            cout << "No existe el deposito que esta buscando" << endl;
            iteraciones++;
            cout << "Iteraciones: " << iteraciones << endl;
        }
        else {
            arregloPosiciones = new int[cantidadObjetos];

            while (getline(archivo, linea)) {
                stringstream stream(linea);
                string Articulo, depositos;
                cont = 0;
                while (getline(stream, depositos, delimitador)) {
                    if (cont == 2)
                        articulo.insertarUltimo(depositos);
                    if (cont == 3 + eleccionDeposito - 1)
                        Depositos.insertarUltimo(depositos);
                    cont++;
                    iteraciones++;
                }
                sumaProductos = Depositos.sumarDeposito();
                if (sumaProductos <= min) {
                    arregloPosiciones[i] = contador;
                    i++;
                }
                contador++;
                Depositos.vaciar();
                iteraciones++;
            }
            i = 0;
            while (arregloPosiciones[i] >= 0) {
                longitud++;
                i++;
                iteraciones++;
            }
            posicion = new int[longitud];
            for (i = 0; i < longitud; i++) {
                posicion[i] = arregloPosiciones[i];
                iteraciones++;
            }

            articulo.getDatoPorDeposito(posicion, longitud, min, eleccionDeposito);
            cout << "Iteraciones: " << iteraciones << endl;
        }
    }
    if (comandos[0] == "stock" && comandos.size() == 2) {
        //Stock total del art?culo ingresado como argumento
        artic = comandos[1];
        bool comp = false;
        while (getline(archivo, linea)) {
            stringstream stream(linea);
            string depositos, resp;
            cont = 0;
            while (getline(stream, depositos, delimitador)) {
                if (cont == 2)
                    if (depositos == artic)
                        resp = depositos;
                if (cont >= 3 && resp == artic) {
                    Depositos.insertarUltimo(depositos);
                    comp = true;
                }
                cont++;
                iteraciones++;
            }
            if (comp) {
                sumaProductos = Depositos.sumarDeposito();
                break;
            }
            contador++;
            iteraciones++;
        }

        if (comp == false) {
            cout << "El articulo que busco no existe" << endl;
            cout << "Iteraciones: " << iteraciones << endl;
        }
        else {
            cout << "El stock total de '" << artic << "' es: " << sumaProductos << endl;
            cout << "Iteraciones: " << iteraciones << endl;
        }
    }
    else if (comandos[0] == "stock" && comandos.size() == 3) {
        //Stock del art?culo en un dep?sito
        artic = comandos[1];
        eleccionDeposito = std::stoi(comandos[2]);
        bool comp = false;
        if (eleccionDeposito <= contadorAncho - 2 && eleccionDeposito>0) {
            while (getline(archivo, linea)) {
                stringstream stream(linea);
                string depositos, resp;
                cont = 0;
                while (getline(stream, depositos, delimitador) || cont <= 7) {
                    if (cont == 2)
                        if (depositos == artic)
                            resp = depositos;
                    if (cont == (3 + eleccionDeposito - 1) && resp == artic) {
                        Depositos.insertarUltimo(depositos);
                        comp = true;
                    }
                    cont++;
                    iteraciones++;
                }
                if (comp) {
                    sumaProductos = Depositos.sumarDeposito();
                    break;
                }
                contador++;
                iteraciones++;
            }

            if (comp == false) {
                cout << "El articulo que busco no existe" << endl;
                cout << "Iteraciones: " << iteraciones << endl;
            }
            else {
                cout << "El stock de '" << artic << "' en el deposito " << eleccionDeposito << " es: " << sumaProductos << endl;
                cout << "Iteraciones: " << iteraciones << endl;
            }
        }
        else {
            cout << "El deposito que busco no existe" << endl;
            cout << "Iteraciones: " << iteraciones << endl;
        }
    }
    if (comandos[0] == "max_Stock") {
        //Listado de art?culos cuyo stock es igual o supera el n?mero n
        min = std::stoi(comandos[1]);
        if (min > 0) {
            arregloPosiciones = new int[cantidadObjetos];

            while (getline(archivo, linea)) {
                stringstream stream(linea);
                string Articulo, depositos;
                cont = 0;
                while (getline(stream, depositos, delimitador)) {
                    if (cont == 2)
                        articulo.insertarUltimo(depositos);
                    if (cont >= 3)
                        Depositos.insertarUltimo(depositos);
                    cont++;
                    iteraciones++;
                }
                sumaProductos = Depositos.sumarDeposito();
                if (sumaProductos >= min) {
                    arregloPosiciones[i] = contador;
                    i++;
                }
                contador++;
                Depositos.vaciar();
                iteraciones++;
            }
            i = 0;
            while (arregloPosiciones[i] >= 0) {
                longitud++;
                i++;
                iteraciones++;
            }
            posicion = new int[longitud];
            for (i = 0; i < longitud; i++) {
                posicion[i] = arregloPosiciones[i];
                iteraciones++;
            }

            articulo.getDato(posicion, longitud, min, false);
            cout << "Iteraciones: " << iteraciones << endl;
        }
        else {
            cout << "No puede ingresar un numero negativo en ese campo." << endl;
            cout << "Iteraciones: " << iteraciones << endl;
        }
    }

    clock_t end = clock();
    double elapsed_secs = static_cast<double>(end - begin) / CLOCKS_PER_SEC;

    cout << "Tardo elapsed_secs" << elapsed_secs << "\n" << std::endl;

    return 0;
}